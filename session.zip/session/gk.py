import requests
import random
from time import sleep
while True:
    u1 = "".join(random.choice("qwertyuiopasdfghjklzxcvbnm1234567890") for i in range(1))
    u2 = "".join(random.choice("qwertyuiopasdfghjklzxcvbnm1234567890") for i in range(5))
    user = f'{u1}{u2}{u1}__'
    url = 'https://www.instagram.com/api/v1/web/accounts/web_create_ajax/attempt/'

    headers2 = {
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'ps_n=1; ps_l=1; mid=ZolIMgALAAFCpKH3oT10TX8CmwBs; ig_did=50CC7611-CA1B-459F-A1F3-0E96A6F05272; ig_nrcb=1; datr=MUiJZh5iF82SYOqwH0rJrMot; shbid="6784\\054283381908\\0541755371177:01f7ba1270b4256c51b1c019505513fb1e68627c48285d4328be06b9f8f609f9bb17b8d9"; shbts="1723835177\\054283381908\\0541755371177:01f7800f59bfc39d91c2190446712eac0a5c655b9d71a732be0eed5cf5c0fc9e0e365515"; rur="NCG\\054283381908\\0541755371322:01f78f94d2cd9d23fa54b86a28bf25bc272442fe4729ad64decf146b74765e424b69443c"; csrftoken=Dke7NYMITAbTFEFZIqDvhnnmRgpxUsxo; wd=1207x969',
    'origin': 'https://www.instagram.com',
    'priority': 'u=1, i',
    'referer': 'https://www.instagram.com/accounts/emailsignup/',
    'sec-ch-prefers-color-scheme': 'dark',
    'sec-ch-ua': '"Opera GX";v="111", "Chromium";v="125", "Not.A/Brand";v="24"',
    'sec-ch-ua-full-version-list': '"Opera GX";v="111.0.5168.90", "Chromium";v="125.0.6422.143", "Not.A/Brand";v="24.0.0.0"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-model': '""',
    'sec-ch-ua-platform': '"Windows"',
    'sec-ch-ua-platform-version': '"10.0.0"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36 OPR/111.0.0.0',
    'x-asbd-id': '129477',
    'x-csrftoken': 'Dke7NYMITAbTFEFZIqDvhnnmRgpxUsxo',
    'x-ig-app-id': '936619743392459',
    'x-ig-www-claim': 'hmac.AR2ROPQaXkvdvha2ffkd_lQVTiJWu1-wmgw5UywLa6zjA-Fb',
    'x-instagram-ajax': '1015733642',
    'x-requested-with': 'XMLHttpRequest',
    }
    data = {
        'enc_password': '#PWD_INSTAGRAM_BROWSER:10:1723767118:AcNQAOTwcUCe9vN7DR16W9/AC4lT7n0NZ+/Nd/Ezp+UCqQoykvLi4IGJI+tdhg7Bt0RPciMGOSCoZSrIpHlSnibr8YyPCAEjgHe8BKku0B3BE4tAgYHwLiYzUU9TQVqkB5bTZuUCeVh8CuAGLQw=',
        'email': 'zodhokmgmgm4374gm@gmail.com',
        'first_name': 'zaid47rali',

        'username': user,

        'opt_into_one_tap': 'false',
    }

    res = requests.post(url, headers=headers2, data=data).text
    sleep(2)
    if '"dryrun_passed":true,' in res:
        print(f"Username Good🤑 : {user}")

    else:
        print(f"Username Badd : {user}         {res}")
