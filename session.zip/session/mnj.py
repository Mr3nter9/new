from telethon.sync import TelegramClient ,errors , events , Button
from telethon import  Button
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import GetHistoryRequest
from telethon.tl.functions.account import UpdateProfileRequest
from telethon.tl.functions.photos import UploadProfilePhotoRequest
import re
from telethon import functions
import requests
from time import sleep
import phonenumbers
from phonenumbers import geocoder
from telethon.tl.types import MessageActionGiftCode

DEX = '6140911166'
people = 1
api_id = 2192036
api_hash = '3b86a67fc4e14bd9dcfc2f593e75c841'
bot_token = '5881397869:AAGfRWKE2I0LXzYeP8OId9mnbEA_fSLiH5Y'
bot = TelegramClient('bot7d', api_id, api_hash).start(bot_token=bot_token)

@bot.on(events.NewMessage())
async def BotOnStart(event):
    text = event.message.message
    if '@' in text:
        await event.reply('ok')
        G = 1
        for ffguf in range(73):
            cc = ("dex" + str(G))
            api_id = '2192036'
            api_hash = '3b86a67fc4e14bd9dcfc2f593e75c841'
            client = TelegramClient(cc, api_id, api_hash)
            await client.connect()
            if not await client.is_user_authorized():
                print(f'{cc} fff')
                G += 1
            elif await client.is_user_authorized():
                await client(JoinChannelRequest(text))
                print(cc)
                await client.disconnect()
                G += 1
        await event.reply('finish')



@bot.on(events.CallbackQuery(data="check"))
async def Callbacks(event):
    gifts = []
    file = open('gifts.txt', 'r')
    for gift in file:
        gif = gift.replace('\n','')
        gifts.append(gif)
    file.close()
    await event.reply('ok')
    G = 1
    for ffguf in range(73):
        cc = ("dex" + str(G))
        api_id = '2192036'
        api_hash = '3b86a67fc4e14bd9dcfc2f593e75c841'
        client = TelegramClient(cc, api_id, api_hash)
        await client.connect()
        if not await client.is_user_authorized():
            print(f'{cc} fff')
            G += 1
        elif await client.is_user_authorized():
            mess = await client.get_messages(777000, limit=20)
            for mes in mess:
                if mes.action:
                    messs=mes.action.slug
                    if not messs in gifts:
                        await event.reply(messs)
                        file = open('gifts.txt', 'a')
                        file.write(messs + '\n')
                        file.close()
            await client.disconnect()
            G += 1
    await event.reply('finish')
@bot.on(events.CallbackQuery(data="Vip"))
async def Callbacks(event):
    async with bot.conversation(event.chat_id, timeout=300) as conv:
        await conv.send_message('username with out @ ?')
        username = await conv.get_response()
        username = username.message
        idx = await bot.get_entity(username)
        id = idx.id
        file = open('memchan.txt', 'a')
        file.write(str(id)+'\n')
        file.close()

@bot.on(events.CallbackQuery(data="remove_"))
async def Callbacks(event):
    await event.delete()
    G = 1
    file = open('memchan.txt','r')
    file.read()
    for ffguf in range(73):
        cc = ("dex" + str(G))
        api_id = '2192036'
        api_hash = '3b86a67fc4e14bd9dcfc2f593e75c841'
        client = TelegramClient(cc, api_id, api_hash)
        await client.connect()
        if not await client.is_user_authorized():
            print(f'{cc} fff')
            G += 1
        elif await client.is_user_authorized():
            dialogs =await client.get_dialogs()
            for dialog in dialogs:
                entity = dialog.entity
                if dialog.is_user:
                    pass
                elif entity.id in file:
                    pass
                else:
                    await client.delete_dialog(entity)
            await client.disconnect()
            G += 1
    await event.reply('finish')
    file.close()


@bot.on(events.NewMessage(pattern='/start'))
async def gag(event):
    buttons = [[Button.inline("remove", "remove_")],[Button.inline("add Vip", "Vip")],[Button.inline("check", "check")]]
    await event.reply('what you need',buttons=buttons)
bot.run_until_disconnected()