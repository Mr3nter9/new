from dex import AsiaCell
asia = AsiaCell()
pid = asia.login(7750642251)
code = input('code ')
asia.verify_login(pid, code)
