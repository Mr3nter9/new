from asiacell import AsiaCell
asia = AsiaCell(7750642251)
pid = asia.login()
code = input('code ')
asia.verify_login(pid, code)
