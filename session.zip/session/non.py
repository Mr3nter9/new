from dex import Asiacell
from utils.models import Bundle
n1 = "eyJhbGciOiJIUzUxMiJ9.eyJzZXNzaW9uSUQiOjg0NzMwMTEsImV4cCI6MTcyMzkyODEwMn0.UjXiTIj1GJgxMPHHe-arrCStfyXpLIWiJZPwqUHuAV7XL3iBkNxOr7b3R_8E5wHexieterUCjiaUnF1jZFlGYw"
n2 = "eyJhbGciOiJIUzUxMiJ9.eyJzZXNzaW9uSUQiOjg0NzMwMTEsInR5cGUiOiJyZWZyZXNoVG9rZW4iLCJleHAiOjE3MjkwMjU3MDJ9._LhleqCTZfegYoZRXsRdwMg6b_f-66-NPO2kVxWvifyPWkE8lc3K6izf6B2MoZlJLE9IS_QHqSGEj7yEYhN_dg"
asia = Asiacell("07750642243")

pid = asia.login_tokens(n1,n2)

