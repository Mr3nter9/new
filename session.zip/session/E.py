from telethon.sync import TelegramClient ,errors
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import GetHistoryRequest
from telethon.tl.functions.account import UpdateProfileRequest , UpdateUsernameRequest
from telethon.tl.functions.photos import UploadProfilePhotoRequest
import re
from telethon import functions
import requests
from time import sleep
import phonenumbers
from phonenumbers import geocoder

def dex1():
    v = input("  How many Accounts to add?  ")
    c = input("  How many Accounts you added?  ")
    G = (int(c)+1)
    b=int(v)+int(c)
    for ffguf in range(int(v)):
        cc = ("dex" + str(G))
        api_id = '2192036'
        api_hash = '3b86a67fc4e14bd9dcfc2f593e75c841'
        client = TelegramClient(cc, api_id, api_hash)
        client.connect()
        if not client.is_user_authorized():
            print(f'{cc} fff')
            G += 1
        elif client.is_user_authorized():
            password_info = client(functions.account.GetPasswordRequest())
            if password_info.has_password:
                ses = True
            else:
                ses = False
            me = client.get_me()
            phone = me.phone
            phone_number = phonenumbers.parse(f'+{phone}')
            country = geocoder.description_for_number(phone_number, "ar")
            about = f'{cc} ok {phone} {country} {me.id} {me.first_name} {me.last_name} {me.username} {ses}'
            print(about)
            mess = client.get_messages(777000,limit=20)
            for mes in mess:
                if mes.action:
                    print(mes.action)
            #dialogs = client.get_dialogs()
            #for dialog in dialogs:
                #entity = dialog.entity
                #if dialog.is_user:
                    #pass
                #else:
                    #client.delete_dialog(entity)
            #sessions = client(functions.account.GetAuthorizationsRequest())
            #for session in sessions.authorizations:
                #if not session.current:
                    #client(functions.account.ResetAuthorizationRequest(session.hash))
                    #print(f'Removed session: {session.device_model}')
            #client(UpdateProfileRequest(first_name=f'Dex - {G}',last_name=''))
            #client(UpdateUsernameRequest('jsiomkmghsgsh'))
            #file = client.upload_file('photo_2024-07-20_02-12-36.jpg')
            #client(UploadProfilePhotoRequest(file=file))
            client.session.save()
            client.disconnect()
            if G == b:
                print("  Completed")
                break
            G += 1
dex1()