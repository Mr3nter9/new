from telethon.errors import UserBannedInChannelError, PeerFloodError, FloodWaitError
from telethon.sync import TelegramClient , events
from telethon.tl.functions.channels import InviteToChannelRequest, JoinChannelRequest
from telethon.tl.types import InputPeerChannel
from telethon.tl.functions.contacts import AddContactRequest
import time , re
n , b= 0 , 0
g = 1
e = 73
group = 'astrotheme'
def read_and_split_file(lines_per_chunk=10):
    try:
        with open('progress2.txt', 'r') as f:
            last_processed_line = int(f.read().strip())
    except FileNotFoundError:
        last_processed_line = 0

    with open('mem', 'r') as file:
        lines = file.readlines()
    remaining_lines = lines[last_processed_line:]
    chunks = [remaining_lines[i:i + lines_per_chunk] for i in range(0, len(remaining_lines), lines_per_chunk)]
    return chunks, last_processed_line

chunks , last_processed_line= read_and_split_file()
for x in chunks:
    for nan in range(5):
        if g==e:
            g = 1
        cc = ("dex" + str(g))
        client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
        client.connect()
        if not client.is_user_authorized():
            g = g + 1
        else: #khirrahahaah
            try:
                client(JoinChannelRequest(group))
                target_group = client.get_entity(group)
                entity = InputPeerChannel(target_group.id, target_group.access_hash)
                for z in x:
                    user = z.replace('\n', '')
                    n += 1
                    user_to_add = client.get_input_entity(user)
                    invit = client(InviteToChannelRequest(entity, [user_to_add]))
                    if invit.missing_invitees == []:
                        print(f'{cc}  - ✅ [{n} - {b}] {user}  ')
                        b+=1
                        time.sleep(10)
                    else:
                        print(f'{cc}  - ❌ [{n} - {b}] {user}  ')
                        time.sleep(2)
                    last_processed_line += 1
                    with open('progress2.txt', 'w') as f:
                        f.write(str(last_processed_line))

            except UserBannedInChannelError as er :
                print(f'--- {cc} banded')
            except PeerFloodError as er :
                print(f'--- {cc} {er}')
            except FloodWaitError as er :
                print(f'--- {cc} {er}')
            except Exception as er:

                print(er)
            finally:
                g+=1
                client.disconnect()
