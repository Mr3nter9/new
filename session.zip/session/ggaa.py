import phonenumbers
from phonenumbers import geocoder
phone = '+37122263987'
phone_number = phonenumbers.parse(phone)
country = geocoder.description_for_number(phone_number, "ar")
print(country)