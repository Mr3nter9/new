import json ,os
json_file = 'dex.json'


def load_replied_users():
    if os.path.exists(json_file):
        with open(json_file, 'r') as f:
            return json.load(f)
    return {}

# وظيفة لحفظ البيانات إلى ملف JSON
def save_replied_user(id, chan):
    replied_users = load_replied_users()
    replied_users[str(id)] = chan
    with open(json_file, 'w') as f:
        json.dump(replied_users, f)
x= load_replied_users()
print(x['dddd'])
for x in load_replied_users():
    print(x)